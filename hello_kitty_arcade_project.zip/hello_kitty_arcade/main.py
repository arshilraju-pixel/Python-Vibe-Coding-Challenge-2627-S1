"""
HELLO KITTY ARCADE
A pastel Y2K-inspired mini-game collection made with Pygame.

Run:
    python -m pip install -r requirements.txt
    python main.py

Controls:
    Mouse: menus, buttons, cards, and catching stars
    ESC: return to the previous screen / quit from the home screen
    R: restart the current game
"""

import json
import math
import random
import sys
from pathlib import Path

import pygame

# ---------------------------- Setup -----------------------------------------

pygame.init()
pygame.display.set_caption("Hello Kitty Arcade ✧")
WIDTH, HEIGHT = 1000, 700
screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.RESIZABLE)
clock = pygame.time.Clock()
FPS = 60

BASE_DIR = Path(__file__).parent
SAVE_FILE = BASE_DIR / "arcade_scores.json"

# Y2K chrome + candy palette
PINK = (255, 126, 190)
HOT_PINK = (255, 65, 158)
PALE_PINK = (255, 222, 239)
BABY_PINK = (255, 239, 248)
WHITE = (255, 255, 255)
LAVENDER = (211, 190, 255)
PURPLE = (151, 119, 211)
DARK = (92, 54, 91)
SILVER = (205, 215, 231)
CHROME_LIGHT = (250, 253, 255)
CHROME_DARK = (137, 154, 180)
GOLD = (255, 211, 102)
MINT = (155, 238, 211)
RED = (255, 93, 125)

FONT_CACHE = {}
def get_font(size, bold=False):
    key = (size, bold)
    if key not in FONT_CACHE:
        FONT_CACHE[key] = pygame.font.SysFont("arial", size, bold=bold)
    return FONT_CACHE[key]

def load_scores():
    try:
        if SAVE_FILE.exists():
            data = json.loads(SAVE_FILE.read_text(encoding="utf-8"))
            return data if isinstance(data, dict) else {}
    except (OSError, json.JSONDecodeError):
        pass
    return {}

scores = load_scores()

def save_scores():
    try:
        SAVE_FILE.write_text(json.dumps(scores, indent=2), encoding="utf-8")
    except OSError:
        pass

def best_score(key):
    return scores.get(key, 0)

def update_best(key, value):
    if value > best_score(key):
        scores[key] = value
        save_scores()

def clamp(value, low, high):
    return max(low, min(high, value))

# ---------------------------- Drawing helpers ------------------------------

def draw_text(surface, text, size, color, center, bold=False):
    image = get_font(size, bold).render(str(text), True, color)
    rect = image.get_rect(center=center)
    surface.blit(image, rect)
    return rect

def draw_gradient(surface, rect, top, bottom, vertical=True):
    x, y, w, h = rect
    steps = max(1, h if vertical else w)
    for i in range(steps):
        t = i / max(1, steps - 1)
        color = tuple(int(top[c] * (1 - t) + bottom[c] * t) for c in range(3))
        if vertical:
            pygame.draw.line(surface, color, (x, y + i), (x + w, y + i))
        else:
            pygame.draw.line(surface, color, (x + i, y), (x + i, y + h))

def rounded_panel(surface, rect, radius=24, fill=WHITE, outline=WHITE, width=2, shadow=True):
    rect = pygame.Rect(rect)
    if shadow:
        shadow_rect = rect.move(0, 7)
        pygame.draw.rect(surface, (220, 157, 196), shadow_rect, border_radius=radius)
    pygame.draw.rect(surface, fill, rect, border_radius=radius)
    if outline:
        pygame.draw.rect(surface, outline, rect, width, border_radius=radius)

def sparkle(surface, x, y, size, color=WHITE):
    pygame.draw.line(surface, color, (x - size, y), (x + size, y), max(1, size // 3))
    pygame.draw.line(surface, color, (x, y - size), (x, y + size), max(1, size // 3))
    pygame.draw.line(surface, color, (x - size // 2, y - size // 2),
                     (x + size // 2, y + size // 2), 1)
    pygame.draw.line(surface, color, (x - size // 2, y + size // 2),
                     (x + size // 2, y - size // 2), 1)

def draw_bow(surface, x, y, scale=1):
    left = [(x, y), (x - 23*scale, y - 16*scale),
            (x - 28*scale, y + 5*scale), (x - 4*scale, y + 8*scale)]
    right = [(x, y), (x + 23*scale, y - 16*scale),
             (x + 28*scale, y + 5*scale), (x + 4*scale, y + 8*scale)]
    pygame.draw.polygon(surface, HOT_PINK, left)
    pygame.draw.polygon(surface, HOT_PINK, right)
    pygame.draw.polygon(surface, WHITE, left, max(1, int(2*scale)))
    pygame.draw.polygon(surface, WHITE, right, max(1, int(2*scale)))
    pygame.draw.circle(surface, GOLD, (int(x), int(y)), max(3, int(5*scale)))

def draw_kitty(surface, x, y, scale=1):
    # Original simple cat mascot illustration (not an official Sanrio asset).
    head = pygame.Rect(0, 0, int(132*scale), int(105*scale))
    head.center = (x, y)
    ears = [
        [(x-48*scale, y-34*scale), (x-55*scale, y-77*scale), (x-18*scale, y-52*scale)],
        [(x+48*scale, y-34*scale), (x+55*scale, y-77*scale), (x+18*scale, y-52*scale)]
    ]
    for ear in ears:
        pygame.draw.polygon(surface, WHITE, ear)
        pygame.draw.polygon(surface, DARK, ear, max(1, int(3*scale)))
    pygame.draw.ellipse(surface, WHITE, head)
    pygame.draw.ellipse(surface, DARK, head, max(1, int(3*scale)))
    # Eyes, nose and whiskers
    pygame.draw.ellipse(surface, DARK, (x-28*scale, y-2*scale, 7*scale, 13*scale))
    pygame.draw.ellipse(surface, DARK, (x+21*scale, y-2*scale, 7*scale, 13*scale))
    pygame.draw.ellipse(surface, GOLD, (x-5*scale, y+13*scale, 10*scale, 7*scale))
    for side in (-1, 1):
        for offset in (-12, 0, 12):
            start_x = x + side*48*scale
            end_x = x + side*68*scale
            yy = y + offset*scale
            pygame.draw.line(surface, DARK, (start_x, yy), (end_x, yy-3*scale), max(1, int(2*scale)))
    draw_bow(surface, x+43*scale, y-43*scale, .75*scale)

class Button:
    def __init__(self, rect, label, callback, color=PINK, text_color=WHITE, subtitle=None):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.callback = callback
        self.color = color
        self.text_color = text_color
        self.subtitle = subtitle

    def draw(self, surface, mouse):
        hover = self.rect.collidepoint(mouse)
        shadow = self.rect.move(0, 5)
        pygame.draw.rect(surface, (204, 145, 185), shadow, border_radius=17)
        fill = tuple(min(255, c + (18 if hover else 0)) for c in self.color)
        pygame.draw.rect(surface, fill, self.rect, border_radius=17)
        pygame.draw.rect(surface, WHITE, self.rect, 2, border_radius=17)
        draw_text(surface, self.label, 21, self.text_color,
                  (self.rect.centerx, self.rect.centery - (8 if self.subtitle else 0)), True)
        if self.subtitle:
            draw_text(surface, self.subtitle, 12, WHITE,
                      (self.rect.centerx, self.rect.centery + 14))
        if hover:
            sparkle(surface, self.rect.right-13, self.rect.top+12, 6, WHITE)

    def click(self, pos):
        if self.rect.collidepoint(pos):
            self.callback()
            return True
        return False

# ---------------------------- Background ------------------------------------

stars = []
for _ in range(65):
    stars.append([random.randrange(WIDTH), random.randrange(HEIGHT),
                  random.choice([2, 3, 4]), random.random() * math.tau])

def draw_background(surface, tick):
    draw_gradient(surface, (0, 0, surface.get_width(), surface.get_height()),
                  (255, 231, 245), (220, 216, 255))
    w, h = surface.get_size()
    for x, y, size, phase in stars:
        xx = int((x + tick * 0.012 * (1 + size)) % max(1, w))
        yy = int((y + math.sin(tick * 0.002 + phase) * 7) % max(1, h))
        color = WHITE if math.sin(tick * 0.006 + phase) > -.2 else (255, 180, 218)
        sparkle(surface, xx, yy, size, color)
    # chrome strip at the top
    draw_gradient(surface, (0, 0, w, 12), CHROME_LIGHT, CHROME_DARK)

def draw_header(surface, title, subtitle=""):
    draw_text(surface, title, 34, DARK, (surface.get_width()//2, 49), True)
    if subtitle:
        draw_text(surface, subtitle, 15, PURPLE, (surface.get_width()//2, 80))

# ---------------------------- Game state ------------------------------------

state = "home"
buttons = []
message = ""
message_until = 0

def set_message(text, duration=1800):
    global message, message_until
    message = text
    message_until = pygame.time.get_ticks() + duration

def go_home():
    global state
    state = "home"

def make_menu_buttons():
    global buttons
    w, h = screen.get_size()
    cx = w // 2
    buttons = [
        Button((cx-155, 230, 310, 64), "MEMORY MATCH", lambda: start_memory(),
               HOT_PINK, subtitle="find all the matching pairs"),
        Button((cx-155, 315, 310, 64), "REACTION RACE", lambda: start_reaction(),
               PURPLE, subtitle="test your speed"),
        Button((cx-155, 400, 310, 64), "STAR CATCHER", lambda: start_catcher(),
               (111, 171, 218), subtitle="catch the falling sparkle stars"),
        Button((cx-155, 505, 310, 48), "BACK TO HOME", go_home, (185, 155, 205)),
    ]

# ---------------------------- Memory Match ----------------------------------

memory_symbols = ["BOW", "HEART", "STAR", "CLOUD", "CHERRY", "GEM", "MOON", "CAKE"]
memory_colors = [HOT_PINK, RED, GOLD, (127, 190, 239), RED, PURPLE, (128, 151, 220), (255, 159, 190)]
memory_cards = []
memory_flipped = []
memory_matched = set()
memory_moves = 0
memory_start = 0
memory_lock_until = 0

def start_memory():
    global state, memory_cards, memory_flipped, memory_matched, memory_moves, memory_start, memory_lock_until
    deck = list(range(len(memory_symbols))) * 2
    random.shuffle(deck)
    memory_cards = deck
    memory_flipped = []
    memory_matched = set()
    memory_moves = 0
    memory_start = pygame.time.get_ticks()
    memory_lock_until = 0
    state = "memory"

def memory_click(pos):
    global memory_flipped, memory_moves, memory_lock_until
    if pygame.time.get_ticks() < memory_lock_until or len(memory_flipped) >= 2:
        return
    w, h = screen.get_size()
    card_w, card_h, gap = 112, 83, 13
    total_w = 4*card_w + 3*gap
    start_x = (w-total_w)//2
    start_y = 176
    for idx in range(16):
        row, col = divmod(idx, 4)
        rect = pygame.Rect(start_x+col*(card_w+gap), start_y+row*(card_h+gap), card_w, card_h)
        if rect.collidepoint(pos) and idx not in memory_matched and idx not in memory_flipped:
            memory_flipped.append(idx)
            if len(memory_flipped) == 2:
                memory_moves += 1
                a, b = memory_flipped
                if memory_cards[a] == memory_cards[b]:
                    memory_matched.update((a, b))
                    memory_flipped = []
                    if len(memory_matched) == 16:
                        elapsed = (pygame.time.get_ticks()-memory_start)//1000
                        score = max(0, 1000 - memory_moves*25 - elapsed*3)
                        update_best("memory", score)
                        set_message(f"PERFECT MATCH! Score: {score}", 3000)
                else:
                    memory_lock_until = pygame.time.get_ticks()+750
            return

def draw_memory(surface):
    draw_header(surface, "MEMORY MATCH", "Find all 8 pairs • fewer moves = a higher score")
    draw_text(surface, f"MOVES  {memory_moves}", 18, DARK, (surface.get_width()//2-100, 123), True)
    draw_text(surface, f"BEST  {best_score('memory')}", 18, DARK, (surface.get_width()//2+100, 123), True)
    w = surface.get_width()
    card_w, card_h, gap = 112, 83, 13
    start_x = (w-(4*card_w+3*gap))//2
    start_y = 176
    for idx in range(16):
        row, col = divmod(idx, 4)
        rect = pygame.Rect(start_x+col*(card_w+gap), start_y+row*(card_h+gap), card_w, card_h)
        if idx in memory_matched or idx in memory_flipped:
            pygame.draw.rect(surface, WHITE, rect, border_radius=14)
            pygame.draw.rect(surface, memory_colors[memory_cards[idx]], rect, 3, border_radius=14)
            draw_text(surface, memory_symbols[memory_cards[idx]], 17,
                      memory_colors[memory_cards[idx]], rect.center, True)
        else:
            draw_gradient(surface, rect, (255, 145, 199), (191, 153, 229))
            pygame.draw.rect(surface, WHITE, rect, 3, border_radius=14)
            draw_bow(surface, rect.centerx, rect.centery, .65)
            draw_text(surface, "♡", 19, WHITE, (rect.centerx, rect.centery+22), True)
    if len(memory_matched) == 16:
        rounded_panel(surface, (w//2-190, 590, 380, 55), 18, WHITE, HOT_PINK)
        draw_text(surface, "YOU DID IT! Press R to play again", 17, HOT_PINK,
                  (w//2, 617), True)

# ---------------------------- Reaction Race ---------------------------------

reaction_phase = "ready"
reaction_start = 0
reaction_wait = 0
reaction_result = None
reaction_best = None

def start_reaction():
    global state, reaction_phase, reaction_start, reaction_wait, reaction_result
    state = "reaction"
    reaction_phase = "ready"
    reaction_start = 0
    reaction_wait = 0
    reaction_result = None

def reaction_click():
    global reaction_phase, reaction_start, reaction_wait, reaction_result, reaction_best
    now = pygame.time.get_ticks()
    if reaction_phase == "ready":
        reaction_phase = "waiting"
        reaction_wait = now + random.randint(1700, 4200)
    elif reaction_phase == "waiting":
        reaction_phase = "early"
        reaction_result = None
    elif reaction_phase == "go":
        reaction_result = now - reaction_start
        reaction_phase = "result"
        reaction_best = reaction_result if reaction_best is None else min(reaction_best, reaction_result)
        old = best_score("reaction")
        if old == 0 or reaction_result < old:
            scores["reaction"] = reaction_result
            save_scores()
    elif reaction_phase in ("early", "result"):
        reaction_phase = "ready"
        reaction_result = None

def draw_reaction(surface):
    global reaction_phase, reaction_start
    now = pygame.time.get_ticks()
    if reaction_phase == "waiting" and now >= reaction_wait:
        reaction_phase = "go"
        reaction_start = now
    draw_header(surface, "REACTION RACE", "Wait for the screen to turn mint, then click as fast as you can!")
    panel = pygame.Rect(surface.get_width()//2-260, 170, 520, 330)
    if reaction_phase == "go":
        fill, outline = MINT, WHITE
        title, sub = "CLICK NOW!", "GO GO GO!"
    elif reaction_phase == "waiting":
        fill, outline = (255, 207, 226), WHITE
        title, sub = "WAIT FOR IT...", "Don't click too early!"
    elif reaction_phase == "early":
        fill, outline = (255, 195, 205), RED
        title, sub = "TOO EARLY!", "Click to try again"
    elif reaction_phase == "result":
        fill, outline = WHITE, HOT_PINK
        title, sub = f"{reaction_result} ms", "Click to play another round"
    else:
        fill, outline = WHITE, HOT_PINK
        title, sub = "READY?", "Click to start"
    rounded_panel(surface, panel, 30, fill, outline, 4)
    draw_text(surface, title, 42, DARK, (panel.centerx, panel.centery-22), True)
    draw_text(surface, sub, 18, PURPLE, (panel.centerx, panel.centery+38))
    draw_text(surface, f"PERSONAL BEST  {best_score('reaction') or '—'} ms", 18,
              DARK, (surface.get_width()//2, 550), True)

# ---------------------------- Star Catcher ----------------------------------

player_x = 500
falling_stars = []
catch_score = 0
catch_lives = 3
catch_start = 0
catch_spawn = 0
catch_finished = False
catch_duration = 45_000

def start_catcher():
    global state, player_x, falling_stars, catch_score, catch_lives, catch_start, catch_spawn, catch_finished
    state = "catcher"
    player_x = screen.get_width()//2
    falling_stars = []
    catch_score = 0
    catch_lives = 3
    catch_start = pygame.time.get_ticks()
    catch_spawn = catch_start
    catch_finished = False

def draw_catcher(surface):
    global catch_finished
    now = pygame.time.get_ticks()
    remaining = max(0, catch_duration - (now-catch_start))
    if not catch_finished:
        if now-catch_spawn > 620:
            falling_stars.append([random.randint(35, surface.get_width()-35), -15,
                                  random.uniform(2.2, 4.8), random.choice([GOLD, WHITE, HOT_PINK, LAVENDER])])
            catch_spawn = now
        for star in falling_stars[:]:
            star[1] += star[2]
            if star[1] > surface.get_height()-85:
                falling_stars.remove(star)
                catch_lives -= 1
                if catch_lives <= 0:
                    catch_finished = True
        if remaining <= 0:
            catch_finished = True
        # collision
        basket = pygame.Rect(player_x-55, surface.get_height()-92, 110, 28)
        for star in falling_stars[:]:
            if basket.collidepoint(star[0], star[1]):
                falling_stars.remove(star)
                catch_score += 10
        if catch_finished:
            update_best("catcher", catch_score)
            set_message(f"TIME! Final score: {catch_score}", 2500)
    draw_header(surface, "STAR CATCHER", "Move your basket with the mouse • catch stars, avoid missing them")
    draw_text(surface, f"SCORE  {catch_score}", 19, DARK, (surface.get_width()//2-180, 120), True)
    draw_text(surface, f"LIVES  {'♥ '*catch_lives}", 19, HOT_PINK, (surface.get_width()//2, 120), True)
    draw_text(surface, f"TIME  {remaining//1000}s", 19, DARK, (surface.get_width()//2+180, 120), True)
    for star in falling_stars:
        x, y, speed, color = star
        sparkle(surface, int(x), int(y), 10, color)
        pygame.draw.circle(surface, WHITE, (int(x), int(y)), 3)
    basket = pygame.Rect(player_x-55, surface.get_height()-92, 110, 28)
    pygame.draw.ellipse(surface, HOT_PINK, basket)
    pygame.draw.ellipse(surface, WHITE, basket, 3)
    draw_text(surface, "♡", 25, WHITE, basket.center, True)
    if catch_finished:
        rounded_panel(surface, (surface.get_width()//2-190, 290, 380, 125), 22, WHITE, HOT_PINK, 3)
        draw_text(surface, "GAME OVER!", 30, HOT_PINK, (surface.get_width()//2, 330), True)
        draw_text(surface, f"Your score: {catch_score}  •  Press R to replay", 16, DARK,
                  (surface.get_width()//2, 375))

# ---------------------------- Screens ---------------------------------------

def draw_home(surface, tick):
    w, h = surface.get_size()
    draw_text(surface, "HELLO KITTY", 49, HOT_PINK, (w//2, 112), True)
    draw_text(surface, "ARCADE", 30, PURPLE, (w//2, 157), True)
    # chrome title underline
    draw_gradient(surface, (w//2-155, 180, 310, 7), CHROME_LIGHT, CHROME_DARK, False)
    draw_kitty(surface, w//2, 300 + math.sin(tick*0.003)*5, 1.05)
    draw_text(surface, "♡  PRESS PLAY & LET THE SPARKLES BEGIN  ♡", 17, DARK,
              (w//2, 405), True)
    play = Button((w//2-130, 455, 260, 66), "PLAY ARCADE  ✧",
                  lambda: set_state("menu"), HOT_PINK)
    play.draw(surface, pygame.mouse.get_pos())
    draw_text(surface, "MEMORY  •  REACTION  •  STAR CATCHER", 13, PURPLE,
              (w//2, 555))
    draw_text(surface, "Y2K EDITION  /  MADE WITH PYTHON", 12, CHROME_DARK,
              (w//2, h-30), True)

def set_state(new_state):
    global state
    state = new_state
    if new_state == "menu":
        make_menu_buttons()

def draw_menu(surface):
    draw_header(surface, "CHOOSE YOUR GAME", "Pick a mini-game and earn your sparkle status!")
    draw_kitty(surface, surface.get_width()//2, 154, .42)
    for button in buttons:
        button.draw(surface, pygame.mouse.get_pos())
    draw_text(surface, "YOUR HIGH SCORES", 15, DARK, (surface.get_width()//2, 590), True)
    draw_text(surface,
              f"Memory: {best_score('memory')}     Reaction: {best_score('reaction') or '—'} ms     Star Catcher: {best_score('catcher')}",
              14, PURPLE, (surface.get_width()//2, 618))

def draw_footer(surface):
    draw_text(surface, "ESC  •  BACK TO MENU", 12, PURPLE, (105, surface.get_height()-20), True)

# ---------------------------- Main loop --------------------------------------

running = True
while running:
    dt = clock.tick(FPS)
    tick = pygame.time.get_ticks()
    mouse = pygame.mouse.get_pos()
    width, height = screen.get_size()
    if width < 760 or height < 620:
        # Keep the layout readable on smaller windows.
        pass

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        elif event.type == pygame.VIDEORESIZE:
            screen = pygame.display.set_mode(event.size, pygame.RESIZABLE)
            if state == "menu":
                make_menu_buttons()
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if state == "home":
                    running = False
                else:
                    set_state("menu")
            elif event.key == pygame.K_r:
                if state == "memory":
                    start_memory()
                elif state == "reaction":
                    start_reaction()
                elif state == "catcher":
                    start_catcher()
        elif event.type == pygame.MOUSEMOTION and state == "catcher" and not catch_finished:
            player_x = clamp(event.pos[0], 60, screen.get_width()-60)
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if state == "home":
                play_rect = pygame.Rect(screen.get_width()//2-130, 455, 260, 66)
                if play_rect.collidepoint(event.pos):
                    set_state("menu")
            elif state == "menu":
                for button in buttons:
                    if button.click(event.pos):
                        break
            elif state == "memory":
                if event.pos[1] < 100 and event.pos[0] < 150:
                    set_state("menu")
                else:
                    memory_click(event.pos)
            elif state == "reaction":
                reaction_click()
            elif state == "catcher" and catch_finished:
                pass

    draw_background(screen, tick)
    if state == "home":
        draw_home(screen, tick)
    elif state == "menu":
        draw_menu(screen)
    elif state == "memory":
        draw_memory(screen)
    elif state == "reaction":
        draw_reaction(screen)
    elif state == "catcher":
        draw_catcher(screen)
    draw_footer(screen)
    if message and tick < message_until:
        rounded_panel(screen, (screen.get_width()//2-190, 15, 380, 42), 14, WHITE, HOT_PINK, 2, False)
        draw_text(screen, message, 15, HOT_PINK, (screen.get_width()//2, 36), True)
    elif tick >= message_until:
        message = ""
    pygame.display.flip()

save_scores()
pygame.quit()
sys.exit()
