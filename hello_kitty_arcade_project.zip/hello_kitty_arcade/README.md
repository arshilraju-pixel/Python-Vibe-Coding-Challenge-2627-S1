# Hello Kitty Arcade 🎀

A Y2K-inspired mini-game arcade made with Python and Pygame. It uses a pastel pink, lavender, and chrome-inspired visual style, with an original hand-drawn cat mascot.

## Features
- **Memory Match:** Find 8 matching pairs. Your score rewards fewer moves and less time.
- **Reaction Race:** Wait for the panel to turn mint, then click as quickly as possible. Clicking early is a false start.
- **Star Catcher:** Move your basket with the mouse, catch falling stars, and try not to miss too many.
- **Saved high scores:** Best scores are stored locally in `arcade_scores.json`.
- Animated sparkle background, chrome strip, hover buttons, and custom-drawn mascot.

## Requirements
- Python 3.10+
- Pygame 2.5+

## Run it
Open a terminal in this folder and run:

```bash
python -m pip install -r requirements.txt
python main.py
```

On some systems, use `python3` instead of `python`.

## Controls
- Mouse: click buttons/cards; move mouse to control the Star Catcher basket.
- `ESC`: return to the game menu. From the home screen, it quits.
- `R`: restart the current mini-game.

## Project structure

```text
hello_kitty_arcade/
├── main.py
├── requirements.txt
├── README.md
└── arcade_scores.json   # created automatically after scores are saved
```

## Competition submission

**Project Name:** Hello Kitty Arcade: Y2K Edition

**Project Description:** A Python mini-game arcade with three skill-based games: Memory Match, Reaction Race, and Star Catcher. Players can compete against their own high scores while exploring a pastel Y2K interface with animated sparkles and a custom-drawn mascot.

**Python Libraries Used:** Pygame, json, random, math, pathlib, sys.

**Instructions for Running:** Install the dependency with `python -m pip install -r requirements.txt`, then run `python main.py`.

**Possible future upgrades:** Add sound effects, more mini-games, a settings screen, player profiles, and a leaderboard for multiple players.
